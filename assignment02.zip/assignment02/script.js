// script.js
// UI Element 1: Button changes the background color
var colorBtn = document.getElementById("color-btn");

colorBtn.addEventListener("click", function() {
  var colors = ["lightblue", "lightgreen", "lightyellow", "lightpink", "white"];
  var randomColor = colors[Math.floor(Math.random() * colors.length)];
  document.body.style.backgroundColor = randomColor;
});


// UI Element 2: Text input displays what the user types
var nameInput = document.getElementById("name-input");
var nameDisplay = document.getElementById("name-display");

nameInput.addEventListener("input", function() {
  if (nameInput.value === "") {
    nameDisplay.textContent = "Your name will appear here.";
  } else {
    nameDisplay.textContent = "Hello, " + nameInput.value + "!";
  }
});


// UI Element 3: Select menu changes the font size of a paragraph
var sizeSelect = document.getElementById("size-select");
var sizeDemo = document.getElementById("size-demo");

sizeSelect.addEventListener("change", function() {
  if (sizeSelect.value === "small") {
    sizeDemo.style.fontSize = "12px";
  } else if (sizeSelect.value === "medium") {
    sizeDemo.style.fontSize = "18px";
  } else if (sizeSelect.value === "large") {
    sizeDemo.style.fontSize = "28px";
  }
});
